# Smart Reward Finds — Site Maintenance Guide

**For non-developers using AI assistance**

This guide explains everything you need to know to maintain and grow this website.

---

## 📂 Project Structure Overview

```
smart-reward-finds/
├── public/
│   └── images/           ← Your logo, cover banner, blog images go here
├── src/
│   ├── components/       ← Reusable UI pieces (Header, Footer, cards, etc.)
│   ├── content/
│   │   └── blog/         ← YOUR BLOG POSTS LIVE HERE (.md files)
│   ├── layouts/          ← Page templates (BaseLayout, BlogPostLayout)
│   ├── pages/            ← Each .astro file = one URL on your site
│   └── styles/
│       └── global.css    ← All design tokens (colors, fonts, spacing)
├── astro.config.mjs      ← Astro configuration
└── package.json          ← Project dependencies
```

---

## ✍️ How to Add a New Blog Post

This is the most common task. Here's exactly what to do:

### Step 1: Create a new Markdown file

Navigate to: `src/content/blog/`

Create a new file with a URL-friendly name:
- Use lowercase letters only
- Replace spaces with hyphens
- No special characters

**Examples:**
- `beginner-guide-to-reward-apps.md`
- `5-best-cashback-apps-2025.md`
- `how-to-spot-fake-giveaways.md`

### Step 2: Add the frontmatter (the info at the top)

Every blog post must start with this block (copy and edit it):

```markdown
---
title: "Your Post Title Here"
description: "A 1–2 sentence summary for search engines and social shares. Keep it under 160 characters."
pubDate: 2025-07-01
category: "Gift Card Giveaways"
tags: ["gift cards", "rewards", "beginners"]
featuredImage: "/images/your-image-name.jpg"
featuredImageAlt: "Description of the image for screen readers"
draft: false
ctaLabel: "Explore the offer"
ctaUrl: "https://example.com/your-offer-link"
---
```

**Available categories (use exactly as written):**
- `Gift Card Giveaways`
- `Smart Tools`
- `Reward Apps`
- `Exclusive Offers`
- `Product Finds`
- `How-To Guides`

**Field notes:**
- `draft: true` = post is written but won't show on the live site yet
- `draft: false` = post is live
- `ctaLabel` and `ctaUrl` are optional — only include them if you want a CTA button in the post
- `featuredImage` is optional — defaults to cover banner if left out
- `updatedDate` can be added if you revise a post: `updatedDate: 2025-08-01`

### Step 3: Write your post content

After the closing `---` of the frontmatter, write your post in Markdown:

```markdown
## Heading 2

Normal paragraph text goes here.

### Heading 3

**Bold text** and *italic text* work normally.

- Bullet list item
- Another bullet item

1. Numbered list
2. Second item

[Link text](https://example.com)

> Blockquote for important callouts

---

Horizontal rule to separate sections
```

### Step 4: Save the file and it's live

Once you push to GitHub (see deployment section), the blog index automatically updates and the post gets its own page. No other changes needed.

---

## 🖼️ Images for Blog Posts

### For featured images on posts:

1. Get or create a **16:9 image** (recommended: 1200×675px or 800×450px)
2. Name it clearly: `my-post-topic.jpg` or `my-post-topic.png`
3. Place it in: `public/images/`
4. In your post frontmatter, reference it as: `featuredImage: "/images/my-post-topic.jpg"`

### Image sources (free stock photos):
- **Unsplash** (unsplash.com) — free, high quality, no attribution required
- **Pexels** (pexels.com) — free, good variety
- **Pixabay** (pixabay.com) — free

### For AI-generated images, use these prompts as starting points:

**Gift Card category:**
> "Flat lay of colorful gift cards and a wrapped present on a bright white background, warm orange and pink tones, clean modern style, top-down view"

**Smart Tools category:**
> "Minimal desk setup with laptop, notebook, and coffee cup on a white background, warm tones, productivity aesthetic, clean and modern"

**Reward Apps category:**
> "Smartphone displaying app icons with coins and rewards graphics, flat design illustration, bright orange and pink color scheme"

**How-To Guides:**
> "Open notebook with pen on a clean white background, surrounded by colorful sticky notes and small icons, top-down view, warm tones"

---

## ✏️ How to Edit Homepage Text

File: `src/pages/index.astro`

Look for these sections to edit:

- **Hero headline and description** — search for `hero-title` and `hero-desc`
- **Category cards** — find the `categories` array near the top of the file
- **"How It Works" steps** — find the `howItWorks` array
- **Trust points** — find the `trustPoints` array
- **Pinterest URL** — search for `pinterest.com/smartrewardfinds` and replace with yours

---

## ✏️ How to Edit Other Pages

| Page | File location |
|------|--------------|
| Homepage | `src/pages/index.astro` |
| Blog index | `src/pages/blog/index.astro` |
| About | `src/pages/about.astro` |
| Contact | `src/pages/contact.astro` |
| Privacy Policy | `src/pages/privacy-policy.astro` |
| Affiliate Disclosure | `src/pages/affiliate-disclosure.astro` |
| Disclaimer | `src/pages/disclaimer.astro` |
| Editorial Policy | `src/pages/editorial-policy.astro` |

For each page: open the file, find the text you want to change, edit it, save.

---

## 🖼️ How to Replace the Logo or Cover Banner

1. Prepare your new image file
2. Name it exactly the same as the current file (e.g., `logo.png`) OR use a new name
3. Place it in `public/images/`
4. If you used a new name, search all `.astro` files for the old filename and update references

**Current filenames:**
- Logo: `public/images/logo.png`
- Cover banner: `public/images/cover-banner.png`

---

## 🎨 How to Change Brand Colors

File: `src/styles/global.css`

Find the `:root { }` block at the top. Edit these values:

```css
--coral:  #FF4D6D;   /* Primary accent */
--orange: #FF8C00;   /* Secondary accent */
--yellow: #FFD700;   /* Highlight */
```

All colors across the entire site will update automatically.

---

## 📬 How to Connect the Contact Form

The contact form in `src/pages/contact.astro` is ready to be wired up. Here are your two best options:

---

### OPTION A: Formspree (Easiest — Recommended)

1. Go to **formspree.io** and create a free account
2. Click "New Form"
3. Set your notification email to: `smartrewardfinds@gmail.com`
4. Copy your form endpoint URL — it looks like: `https://formspree.io/f/xxxxxxxx`
5. Open `src/pages/contact.astro`
6. Find this line: `<form id="contact-form" action="#" method="POST">`
7. Replace `action="#"` with your Formspree URL:
   ```html
   <form id="contact-form" action="https://formspree.io/f/xxxxxxxx" method="POST">
   ```
8. Done. Formspree will email you every submission.

**Field names used in the form (Formspree reads these automatically):**
- `name` → Full Name
- `email` → Email Address
- `phone` → Phone Number
- `reason` → Reason for Message
- `message` → Message content
- `_replyto` → Sets reply-to header so you can reply directly from your inbox

---

### OPTION B: Google Apps Script + Google Sheets

This routes submissions to a Google Sheet AND emails you.

#### Step 1: Create a Google Sheet
1. Go to Google Sheets and create a new spreadsheet
2. Name the columns in Row 1:
   `Timestamp | name | email | phone | reason | message`

#### Step 2: Set up the Apps Script
1. In your Sheet, click **Extensions → Apps Script**
2. Delete the existing code and paste this:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = e.parameter;
  
  sheet.appendRow([
    new Date(),
    data.name || '',
    data.email || '',
    data.phone || '',
    data.reason || '',
    data.message || ''
  ]);
  
  // Optional: send email notification
  MailApp.sendEmail({
    to: 'smartrewardfinds@gmail.com',
    subject: 'New Contact Form: ' + (data.reason || 'General'),
    body: 'Name: ' + data.name + '\nEmail: ' + data.email + '\nPhone: ' + data.phone + '\nReason: ' + data.reason + '\nMessage: ' + data.message
  });
  
  return ContentService
    .createTextOutput(JSON.stringify({ result: 'success' }))
    .setMimeType(ContentService.MimeType.JSON);
}
```

3. Click **Deploy → New Deployment**
4. Type: **Web app**
5. Execute as: **Me**
6. Who has access: **Anyone**
7. Click Deploy and copy the deployment URL

#### Step 3: Connect to your form
1. Open `src/pages/contact.astro`
2. Find: `<form id="contact-form" action="#" method="POST">`
3. Replace `action="#"` with your deployment URL

---

## 🚀 How to Deploy to Vercel

### First-time setup:

1. **Create a GitHub account** at github.com (if you don't have one)
2. **Create a new repository** called `smart-reward-finds`
3. **Upload your project files** to the repository
4. **Create a Vercel account** at vercel.com (free)
5. Click **"Add New Project"** in Vercel
6. Connect your GitHub account and select your `smart-reward-finds` repository
7. Vercel will auto-detect Astro — leave settings as default
8. Click **Deploy**

Your site will be live at a URL like `smart-reward-finds.vercel.app`

### Custom domain setup:
1. Buy a domain (Namecheap, GoDaddy, Google Domains, etc.)
2. In Vercel: go to your project → Settings → Domains
3. Add your domain and follow the DNS configuration instructions

### Publishing updates after making changes:

Once connected, every time you push (upload) changes to GitHub, Vercel automatically rebuilds and redeploys your site within ~60 seconds. No manual deploy steps needed.

---

## 📌 Frequently Asked Questions

**Q: I added a blog post but it's not showing up.**
A: Check that `draft: false` is set in the frontmatter. Also make sure the file is in `src/content/blog/` and has the `.md` extension.

**Q: How do I add images inside blog post content?**
A: Upload the image to `public/images/`, then in your Markdown write:
```markdown
![Description of image](/images/your-image.jpg)
```

**Q: The category filter on the blog page isn't working.**
A: Make sure the `category` value in your post frontmatter exactly matches one of the categories listed above (including capitalization).

**Q: How do I make a post a draft while I work on it?**
A: Set `draft: true` in the frontmatter. The post won't appear on the live site until you change it to `draft: false`.

**Q: How do I update the "Last updated" date on legal pages?**
A: Open the relevant page file (e.g., `src/pages/privacy-policy.astro`) and find the `const updated = "June 2025"` line near the top. Change the date string.

**Q: How do I add a new page to the site?**
A: Create a new file in `src/pages/` — for example, `src/pages/resources.astro`. Copy the structure from another simple page like `about.astro`. The URL will automatically be `/resources`.

---

## 💡 Tips for Working with AI on This Site

When asking an AI assistant to help you with this site:

- Share the relevant file content and ask for specific changes
- Say "I'm using Astro with content collections" so the AI understands the setup
- Ask it to "keep the existing design tokens and CSS variables"
- For new blog posts, tell it your topic and ask it to "write a Markdown blog post with the correct frontmatter format for Smart Reward Finds"
- For page edits, paste the section you want to change and describe what you want differently

---

*This maintenance guide was built alongside the Smart Reward Finds website project.*
