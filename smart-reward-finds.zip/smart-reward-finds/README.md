# Smart Reward Finds

A trust-first CPA content website and Pinterest-friendly resource blog built with Astro.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📁 Project Structure

```
smart-reward-finds/
├── public/
│   └── images/              ← Logo, banner, blog post images
├── src/
│   ├── components/
│   │   ├── Header.astro
│   │   ├── Footer.astro
│   │   ├── SEOHead.astro
│   │   ├── PostCard.astro
│   │   ├── CategoryCard.astro
│   │   └── CTABlock.astro
│   ├── content/
│   │   ├── config.ts        ← Blog schema definition
│   │   └── blog/            ← Blog posts (.md files)
│   ├── layouts/
│   │   ├── BaseLayout.astro
│   │   └── BlogPostLayout.astro
│   ├── pages/
│   │   ├── index.astro
│   │   ├── about.astro
│   │   ├── contact.astro
│   │   ├── privacy-policy.astro
│   │   ├── affiliate-disclosure.astro
│   │   ├── disclaimer.astro
│   │   ├── editorial-policy.astro
│   │   ├── 404.astro
│   │   └── blog/
│   │       ├── index.astro
│   │       └── [slug].astro
│   └── styles/
│       └── global.css
├── astro.config.mjs
├── package.json
└── MAINTENANCE_NOTES.md     ← Read this for site maintenance
```

## 📝 Adding Blog Posts

Create a `.md` file in `src/content/blog/` with this frontmatter:

```markdown
---
title: "Your Post Title"
description: "Short description under 160 characters."
pubDate: 2025-07-01
category: "Gift Card Giveaways"
tags: ["tag1", "tag2"]
featuredImage: "/images/your-image.jpg"
featuredImageAlt: "Image description"
draft: false
ctaLabel: "Explore the offer"   # optional
ctaUrl: "https://example.com"   # optional
---

Your post content here...
```

**Available categories:**
- Gift Card Giveaways
- Smart Tools
- Reward Apps
- Exclusive Offers
- Product Finds
- How-To Guides

## 🌐 Deploy to Vercel

1. Push this project to a GitHub repository
2. Connect the repo to Vercel (vercel.com)
3. Vercel auto-detects Astro — deploy with default settings
4. Set up your custom domain in Vercel → Settings → Domains

## 📬 Contact Form Setup

See `MAINTENANCE_NOTES.md` for full instructions on connecting the contact form to:
- **Formspree** (easiest) — free tier available
- **Google Apps Script + Sheets** — for email + spreadsheet storage

## 🎨 Customization

- **Colors:** Edit CSS variables in `src/styles/global.css`
- **Site URL:** Update `site` in `astro.config.mjs`
- **Pinterest URL:** Search for `pinterest.com/smartrewardfinds` in component files
- **Logo:** Replace `public/images/logo.png`

---

See `MAINTENANCE_NOTES.md` for complete beginner-friendly documentation.
